from setuptools import setup, find_packages

setup(
    name='mtr',
    packages=find_packages(),
    description=
    'DRL impementation for ERL line of MTR',
    author='CityU',
    version='0.0.1')